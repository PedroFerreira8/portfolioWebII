import { Component, OnInit } from '@angular/core';
import { Artigo } from 'src/app/classes/artigo';
import { ListaComprasService } from 'src/app/listacompras/lista-compras.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  listaService : ListaComprasService;

  constructor(private lista : ListaComprasService) {
    this.listaService = lista;

  }

  ngOnInit(): void {
  }

  AdicionarLista(nome: string , preco: any){
    if(nome.length > 0 && isNaN(preco) == false){
      this.listaService.listaCompras.push(new Artigo(nome, preco));
    }else{
      console.log("Verifique os campos!")
    }
  }

}
