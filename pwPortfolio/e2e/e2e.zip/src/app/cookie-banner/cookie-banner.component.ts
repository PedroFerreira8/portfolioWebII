import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cookie-banner',
  templateUrl: './cookie-banner.component.html',
  styleUrls: ['./cookie-banner.component.css']
})
export class CookieBannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.lerCookies();
  }

  cookieAccepted : boolean = false;

  aceitarCookies(ctn:HTMLElement){
    localStorage.setItem("cookie", "1");
    ctn.style.display = "none";
    document.getElementById("cookie-banner").style.display = "none";

  }

  lerCookies(){
    this.cookieAccepted = localStorage.getItem("cookie") == "1" ? true : false;
  }
}
