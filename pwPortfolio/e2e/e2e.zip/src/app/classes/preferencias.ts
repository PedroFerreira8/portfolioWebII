
export class Preferencias {
  corDeFundo : string;
  corDeLetra: string;


  constructor(corF : string, corL : string)
  {
    this.corDeFundo = corF;
    this.corDeLetra = corL;
  }
}

