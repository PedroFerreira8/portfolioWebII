import { Component, OnInit } from '@angular/core';
import { ListaComprasService } from 'src/app/listacompras/lista-compras.service';
import { Artigo } from 'src/app/classes/artigo';

@Component({
  selector: 'app-buy',
  templateUrl: './buy.component.html',
  styleUrls: ['./buy.component.css']
})
export class BuyComponent implements OnInit {

  listaService : ListaComprasService;

  constructor(lista : ListaComprasService) {
    this.listaService = lista;

  }

  ngOnInit(): void {
  }
  
  Comprar(artigo : Artigo){
    artigo.carrinho = true;
    console.log("Artigo", artigo)
  }

}
