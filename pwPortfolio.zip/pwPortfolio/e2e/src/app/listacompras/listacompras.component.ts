import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listacompras',
  templateUrl: './listacompras.component.html',
  styleUrls: ['./listacompras.component.css']
})
export class ListacomprasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
