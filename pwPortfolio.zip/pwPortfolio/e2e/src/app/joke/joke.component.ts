import { Component, OnInit } from '@angular/core';
import { AskChuckService } from './ask-chuck.service';

@Component({
  selector: 'app-joke',
  templateUrl: './joke.component.html',
  styleUrls: ['./joke.component.css']
})
export class JokeComponent implements OnInit {

  constructor(private chuckService: AskChuckService) { }

  ngOnInit(): void {
  }
  piada : string = "À ESPERA DA PIADA!";
  resultado : any;
  piadas : any;

  getJoke(){
    this.chuckService.getJoke().subscribe(
      data => {
        this.resultado = data
        this.piada = JSON.stringify(this.resultado.value);
      }
    )
  }

  getMoreJokes(valorAPesquisar: any){
    this.chuckService.getJokeFromCat(valorAPesquisar).subscribe(
      data => {this.piadas = data}
    );
  }

}


