import { NgModule } from '@angular/core';
import { ChildrenOutletContexts, RouterModule, Routes } from '@angular/router';
import { CalculadoraComponent } from './calculadora/calculadora.component';
import { CookieBannerComponent } from './cookie-banner/cookie-banner.component';
import { EvAndRefComponent } from './ev-and-ref/ev-and-ref.component';
import { HomeComponent } from './home/home.component';
import { ErroComponent } from './erro/erro.component';
import { JokeComponent } from './joke/joke.component';
import { ListacomprasComponent } from './listacompras/listacompras.component';
import { PcolorComponent } from './pcolor/pcolor.component';
import { ScolorComponent } from './pcolor/scolor/scolor.component';
import { AddComponent } from './listacompras/add/add.component';
import { BuyComponent } from './listacompras/buy/buy.component';

const routes: Routes = [
  {path: "", component: HomeComponent},
  {path: "home", component: HomeComponent},
  {path: "calculadora", component: CalculadoraComponent},
  {path: "evAndRef", component: EvAndRefComponent},
  {path: "cookies", component : CookieBannerComponent},
  {path: "erro", component : ErroComponent},
  {path: "listacompras", component : ListacomprasComponent,
    children:[
      {path:"add", component:AddComponent},
      {path:"buy", component:BuyComponent}
    ]},
  {path: "pcolor", component : PcolorComponent},
  {path: "scolor", component : ScolorComponent},
  {path: "joke", component : JokeComponent},
  {path:"pcolor", component:PcolorComponent,
    children:[
      {path:":color", component:ScolorComponent}
  ]},

];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
