import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pcolor',
  templateUrl: './pcolor.component.html',
  styleUrls: ['./pcolor.component.css']
})
export class PcolorComponent implements OnInit {

  cor : string;

  constructor() { }

  color : string = ""

  ngOnInit(): void {
  }

  MudarCor(cor : any){
    this.cor = cor;
  }

}
