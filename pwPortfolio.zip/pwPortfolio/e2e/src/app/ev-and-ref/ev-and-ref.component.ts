import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ev-and-ref',
  templateUrl: './ev-and-ref.component.html',
  styleUrls: ['./ev-and-ref.component.css']
})
export class EvAndRefComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  cor : string = "blue";

  trocarCor(refe:HTMLElement, cor : string){
    refe.style.backgroundColor = cor;
  }

  }

