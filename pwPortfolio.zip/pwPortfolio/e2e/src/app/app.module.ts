import { NgModule} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { MatSliderModule } from '@angular/material/slider';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule } from '@angular/material/input';
import { HttpClientModule } from '@angular/common/http';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { CalculadoraComponent } from './calculadora/calculadora.component';
import { HomeComponent } from './home/home.component';
import { FormsModule } from '@angular/forms';
import { EvAndRefComponent } from './ev-and-ref/ev-and-ref.component';
import { CookieBannerComponent } from './cookie-banner/cookie-banner.component';
import { ErroComponent } from './erro/erro.component';
import { ListacomprasComponent } from './listacompras/listacompras.component';
import { PcolorComponent } from './pcolor/pcolor.component';
import { JokeComponent } from './joke/joke.component';
import { AddComponent } from './listacompras/add/add.component';
import { BuyComponent } from './listacompras/buy/buy.component';
import { MatPseudoCheckbox } from '@angular/material/core';


@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    CalculadoraComponent,
    HomeComponent,
    EvAndRefComponent,
    CookieBannerComponent,
    ErroComponent,
    ListacomprasComponent,
    PcolorComponent,
    JokeComponent,
    AddComponent,
    BuyComponent
  ],
  imports: [
    MatSliderModule,
    MatButtonModule,
    MatFormFieldModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    RouterModule,
    MatInputModule,
    HttpClientModule,
    MatCheckboxModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
